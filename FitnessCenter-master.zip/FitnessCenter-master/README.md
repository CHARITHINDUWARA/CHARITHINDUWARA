First level final java project declare a software to fitness center.
