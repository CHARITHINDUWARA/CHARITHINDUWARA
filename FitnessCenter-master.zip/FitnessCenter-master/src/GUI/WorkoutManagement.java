/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;

import Model.MySQL;
import com.formdev.flatlaf.FlatDarkLaf;
import com.mysql.cj.jdbc.Blob;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ACER
 */
public class WorkoutManagement extends javax.swing.JFrame {

    HashMap<String, Integer> bodyPartsMap = new HashMap<>();
    private String storedPath;
    private String existingName;

    private WorkoutGenerator workoutGenerator;

    public void setWorkoutGenerator(WorkoutGenerator workoutGenerator) {
        this.workoutGenerator = workoutGenerator;
    }

    /**
     * Creates new form WorkoutManagement
     */
    public WorkoutManagement() {
        initComponents();
        loadBodyParts();
        searchAndLoadExercise();
        reset();

    }

    private void loadBodyParts() {

        try {
            ResultSet resultSet = MySQL.execute("SELECT * FROM `body_part`");

            Vector v = new Vector();
            v.add("Select");

            while (resultSet.next()) {
                v.add(resultSet.getString("name"));
                bodyPartsMap.put(resultSet.getString("name"), resultSet.getInt("id"));
            }

            DefaultComboBoxModel model = (DefaultComboBoxModel) jComboBox1.getModel();
            model.removeAllElements();
            model.addAll(v);
            jComboBox1.setSelectedIndex(0);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void searchAndLoadExercise() {

        String eName = jTextField1.getText();
        String body_part = String.valueOf(jComboBox1.getSelectedItem());
        ResultSet resultSet;

        try {
            if (eName.isEmpty() & body_part.equals("Select")) {
                resultSet = MySQL.execute("SELECT * FROM `workout` INNER JOIN `body_part` "
                        + "ON `body_part`.`id`=`workout`.`body_part_id`");
            } else if (eName.isEmpty()) {
                resultSet = MySQL.execute("SELECT * FROM `workout` INNER JOIN `body_part` "
                        + "ON `body_part`.`id`=`workout`.`body_part_id` WHERE `body_part`.`name` = '" + body_part + "'");
            } else if (body_part.equals("Select")) {
                resultSet = MySQL.execute("SELECT * FROM `workout` INNER JOIN `body_part` "
                        + "ON `body_part`.`id`=`workout`.`body_part_id` WHERE `workout`.`name` LIKE '%" + eName + "%'");
            } else {
                resultSet = MySQL.execute("SELECT * FROM `workout` INNER JOIN `body_part` "
                        + "ON `body_part`.`id`=`workout`.`body_part_id` WHERE `workout`.`name` LIKE '%" + eName + "%' "
                        + "AND `body_part`.`name`='" + body_part + "'");
            }

            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);

            while (resultSet.next()) {
                Vector v = new Vector();
                v.add(resultSet.getString("workout.id"));
                v.add(resultSet.getString("workout.name"));
                v.add(resultSet.getString("body_part.name"));
                v.add(resultSet.getString("body_part.name"));

                model.addRow(v);
            }

            jTable1.setModel(model);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void insertExerciseProcess() {

        String name = jTextField1.getText();
        String body_part = String.valueOf(jComboBox1.getSelectedItem());
        String description = jTextArea1.getText();

        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter Excercise Name", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (body_part.equals("Select")) {
            JOptionPane.showMessageDialog(this, "Select Body Part", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (description.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter Description", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (storedPath.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Upload an Image", "Error", JOptionPane.ERROR_MESSAGE);
        } else {

            try {
                ResultSet resultSet = MySQL.execute("SELECT * FROM `workout` WHERE `name`='" + name + "'");

                if (!resultSet.next()) {
                    try {
                        MySQL.execute("INSERT INTO `workout`(`name`,`body_part_id`,`description`,`img_path`)"
                                + " VALUES('" + name + "','" + bodyPartsMap.get(body_part) + "',"
                                + "'" + description + "','" + storedPath + "')");

                        JOptionPane.showMessageDialog(this, "Exercise Added Sucessfully", "Success", JOptionPane.INFORMATION_MESSAGE);

                        reset();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Exercise Already Exists", "Already Exists", JOptionPane.ERROR_MESSAGE);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    private void updateExerciseProcess() {
        String name = jTextField1.getText();
        String body_part = String.valueOf(jComboBox1.getSelectedItem());
        String description = jTextArea1.getText();

        if (body_part.equals("Select")) {
            JOptionPane.showMessageDialog(this, "Select Body Part", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (description.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter Description", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (existingName.equals(name)) {
            try {
                MySQL.execute("UPDATE `workout` SET "
                        + "`body_part_id` = '" + bodyPartsMap.get(body_part) + "',"
                        + "`description` = '" + description + "',"
                        + "`img_path`='" + storedPath + "' "
                        + "WHERE `name`='" + name + "'");

                JOptionPane.showMessageDialog(this, "Exercise Updated Sucessfully", "Success", JOptionPane.INFORMATION_MESSAGE);
                reset();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Changing Exercise Name is Not Allowed", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

    private void deleteExerciseProcess() {
        String name = jTextField1.getText();

        try {
            MySQL.execute("DELETE from `workout` WHERE `name`='" + name + "'");

            JOptionPane.showMessageDialog(this, "Exercise Deleted Sucessfully", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
        }

        reset();
    }

    private void uploadImage() {
        JFileChooser chooser = new JFileChooser();
        FileNameExtensionFilter fnef = new FileNameExtensionFilter("PNG JPG AND JPEG", "png", "jpeg", "jpg");
        chooser.addChoosableFileFilter(fnef);
        chooser.showOpenDialog(null);
        File f = chooser.getSelectedFile();
        String filename = f.getAbsolutePath();

        try {
            BufferedImage bi = ImageIO.read(new File(filename));
            Image img = bi.getScaledInstance(255, 222, Image.SCALE_SMOOTH);
            ImageIcon icon = new ImageIcon(img);
            jLabel5.setIcon(icon);
        } catch (Exception e) {
            e.printStackTrace();
        }

        String newPath = "Resources/workoutImages";
        File directory = new File(newPath);
        if (!directory.exists()) {
            directory.mkdirs();
        }

        String eName = jTextField1.getText();

        File sourceFile = null;
        File destinationFile = null;
        String extention = filename.substring(filename.lastIndexOf('.') + 1);
        sourceFile = new File(filename);
        destinationFile = new File(newPath + "/" + eName + "." + extention);
        storedPath = newPath + "/" + eName + "." + extention;

        try {
            Files.copy(sourceFile.toPath(), destinationFile.toPath());
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        String path2 = destinationFile.getAbsolutePath();
        System.out.println(path2);

    }

    private void reset() {
        jTextField1.setText("");
        jLabel5.setIcon(null);
        jTextArea1.setText("");
        jComboBox1.setSelectedIndex(0);
        searchAndLoadExercise();
        storedPath = "";
        existingName = "";

        jButton11.setEnabled(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton11 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("Segoe UI Historic", 1, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(67, 173, 222));
        jLabel2.setText("Workout Database");

        jLabel1.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jLabel1.setText("Exercise Name :");

        jTextField1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField1KeyReleased(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jLabel3.setText("Body Part :");

        jComboBox1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jComboBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox1ItemStateChanged(evt);
            }
        });
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jLabel4.setText("Description     :");

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jButton8.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jButton8.setText("Update");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jButton9.setText("Add");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setFont(new java.awt.Font("Segoe UI Historic", 1, 14)); // NOI18N
        jButton10.setText("Delete");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Exercise Name", "Body Part"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(5);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(200);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
        }

        jButton11.setFont(new java.awt.Font("Segoe UI Historic", 1, 12)); // NOI18N
        jButton11.setText("Upload Image");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Resources/add_icon.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jScrollPane2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(169, 169, 169)
                                        .addComponent(jLabel2))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton1)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(12, 12, 12))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton8)
                            .addComponent(jButton10)
                            .addComponent(jButton9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton11)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        uploadImage();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed

        if (workoutGenerator != null) {
            workoutGenerator.jTextField3().setText(jTextField1.getText());
            workoutGenerator.jTextField8().setText(String.valueOf(jComboBox1.getSelectedItem()));

            this.dispose();
        } else {
            insertExerciseProcess();
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked

        if (evt.getClickCount() == 2) {

            if (workoutGenerator != null) {
                jButton8.setEnabled(false);
                jButton10.setEnabled(false);
                jButton11.setEnabled(false);

                jButton11.setEnabled(true);

                int selectedRow = jTable1.getSelectedRow();

                String id = String.valueOf(jTable1.getValueAt(selectedRow, 0));
                String name = String.valueOf(jTable1.getValueAt(selectedRow, 1));
                String bodyPart = String.valueOf(jTable1.getValueAt(selectedRow, 2));
                String description = "";
                existingName = name;

                try {
                    ResultSet resultSet = MySQL.execute("SELECT * FROM `workout` WHERE `id`='" + id + "'");

                    while (resultSet.next()) {
                        description = resultSet.getString("description");
                        storedPath = resultSet.getString("img_path");

                        BufferedImage bi = ImageIO.read(new File(storedPath));
                        Image img = bi.getScaledInstance(255, 222, Image.SCALE_SMOOTH);
                        ImageIcon icon = new ImageIcon(img);
                        jLabel5.setIcon(icon);
                    }

                    jTextField1.setText(name);
                    jComboBox1.setSelectedItem(bodyPart);
                    jTextArea1.setText(description);

                } catch (Exception e) {
                    e.printStackTrace();
                }

            } else {

                jButton11.setEnabled(true);

                int selectedRow = jTable1.getSelectedRow();

                String id = String.valueOf(jTable1.getValueAt(selectedRow, 0));
                String name = String.valueOf(jTable1.getValueAt(selectedRow, 1));
                String bodyPart = String.valueOf(jTable1.getValueAt(selectedRow, 2));
                String description = "";
                existingName = name;

                try {
                    ResultSet resultSet = MySQL.execute("SELECT * FROM `workout` WHERE `id`='" + id + "'");

                    while (resultSet.next()) {
                        description = resultSet.getString("description");
                        storedPath = resultSet.getString("img_path");

                        BufferedImage bi = ImageIO.read(new File(storedPath));
                        Image img = bi.getScaledInstance(255, 222, Image.SCALE_SMOOTH);
                        ImageIcon icon = new ImageIcon(img);
                        jLabel5.setIcon(icon);
                    }

                    jTextField1.setText(name);
                    jComboBox1.setSelectedItem(bodyPart);
                    jTextArea1.setText(description);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed

        updateExerciseProcess();

    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        reset();
        jTextField1.setEnabled(true);
        jButton11.setEnabled(true);
        jButton9.setEnabled(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed

        deleteExerciseProcess();

    }//GEN-LAST:event_jButton10ActionPerformed

    private void jTextField1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyReleased

        searchAndLoadExercise();
    }//GEN-LAST:event_jTextField1KeyReleased

    private void jComboBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox1ItemStateChanged

        searchAndLoadExercise();
    }//GEN-LAST:event_jComboBox1ItemStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        FlatDarkLaf.setup();

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new WorkoutManagement().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
